let todos = JSON.parse(localStorage.getItem("todos")) || [];
// Lấy chữ trong localStorage → đổi lại thành mảng JS
// Nếu chưa có gì trong localStorage → dùng mảng rỗng []

function add() {
    let text = document.getElementById("text").value;
    if (!text) return; //dừng lại không làm nữa


    todos.push({
        text: text,
        done: false,
    }); // thêm phần tử object vào mảng todos
    // text: nội dung todo
    // done: trạng thái checkbox (mặc định là chưa tick)
    saveTodos(); // lưu vào localStorage qua hàm saveTodos() ở dưới
    render(); //về lại giao diện



    document.getElementById("text").value = "";
    document.getElementById("text").focus();
}

function saveTodos() {
    localStorage.setItem("todos", JSON.stringify(todos));
}

function render() {
    let list = document.getElementById("toDoList");
    list.innerHTML = "";
    // Xóa toàn bộ todo cũ trên giao diện
    // để vẽ lại từ đầu (tránh bị lặp)

    for (let i = 0; i < todos.length; i++) {
        const li = document.createElement("li"); // tạo thẻ li mới, thẻ này mới chi có trong js

        // Gán HTML bên trong cho thẻ li 
        // label: Có label → bấm vào chữ cũng tick được
        li.innerHTML = `
    
    <label> 
    <div>
        <input type="checkbox" ${todos[i].done ? "checked" : ""}>
        <div class="textCheckbox">${todos[i].text}</div>
    </div>
    </label>
    
    `;
        //input đọc và lấy trạng thái trước đó của box từ object
        // todos[i] = từng phần tử trong mảng todos, render() không quan tâm người dùng vừa nhập gì,
        //  Nó chỉ quan tâm mảng todos hiện tại có gì

        const checkbox = li.querySelector("input");
        //lưu thay đổi "change" của checkbox vào todos[i].done -> tích hoặc chưa tích
        checkbox.addEventListener("change", function () {
            todos[i].done = checkbox.checked; // trả về true or false
            // lưu trạng thái mới của checkbox và text;
            saveTodos();
        });

        list.appendChild(li);
        // Gắn thẻ <li> vừa tạo vào trong <ul>
    }
}

render();
// add() chỉ chạy khi bấm nút Add, Còn render(); cuối file chạy NGAY KHI TRANG VỪA LOAD
// nên nếu không bấm nút add thì trang trống không nếu không gọi render ở cuối