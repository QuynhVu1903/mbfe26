
let todos = JSON.parse(localStorage.getItem("todos")) || [];
// function resetAll(){
//     for(let i = 0; i < todos[i]; i++){

//     }
//     console.log(todos);
// }
// resetAll();
//  todos.length = 0;

// Lấy chữ trong localStorage → đổi lại thành mảng JS
// Nếu chưa có gì trong localStorage → dùng mảng rỗng []

// function add() {
//     let text = document.getElementById("text").value;
//     if (!text) return; //dừng lại không làm nữa


//     todos.push({
//         text: text,
//         done: false,
//     }); // thêm phần tử object vào mảng todos
//     // text: nội dung todo
//     // done: trạng thái checkbox (mặc định là chưa tick)
//     saveTodos(); // lưu vào localStorage qua hàm saveTodos() ở dưới
//     render(); //về lại giao diện



//     document.getElementById("text").value = "";
//     document.getElementById("text").focus();
// }

function saveTodos() {
    localStorage.setItem("todos", JSON.stringify(todos));
}

function render() {
    let list = document.getElementById("toDoList");
    list.innerHTML = "";
    // Xóa toàn bộ todo cũ trên giao diện
    // để vẽ lại từ đầu (tránh bị lặp)

    for (let i = 0; i < todos.length; i++) {
        if (todos[i].done === false) continue; // nếu chưa tích thì bỏ qua lần lặp này
        const li = document.createElement("li"); // tạo thẻ li mới, thẻ này mới chi có trong js

        // Gán HTML bên trong cho thẻ li 
        // label: Có label → bấm vào chữ cũng tick được
        li.innerHTML = `
    <div class="boxText">
    <label> 
    <div>
        <input type="checkbox" checked>
 
            <div class="textCheckbox">${todos[i].text}</div>
            

    </div>
    </label>
    </div>
    <div class="smallBin"><i id="iconSmallBin" class="fa-solid fa-trash"></i></div>

    `;
        //input đọc và lấy trạng thái ban đầu của box từ object luôn là đã tích
        // todos[i] = từng phần tử trong mảng todos, render() không quan tâm người dùng vừa nhập gì,
        //  Nó chỉ quan tâm mảng todos hiện tại có gì



        const checkbox = li.querySelector("input");
        const bin = li.querySelector(".smallBin");
        bin.addEventListener("click", function () {
            todos.splice(i, 1); //i là index đang xét
            saveTodos();
            render();
        });


        //nếu có sự thay đổi trong input thì hàm dưới sẽ hoạt động
        //và todo[i].done sẽ chuyển sang trạng thái chưa tích
        checkbox.addEventListener("change", function () {
            todos[i].done = false; // người dùng không tích nữa
            // lưu trạng thái mới của checkbox
            saveTodos();
            location.reload(); //sau khi hủy tích sẽ biến mất và chuyển sang active khi render()

        });

        list.appendChild(li);
        // Gắn thẻ <li> vừa tạo vào trong <ul>
    }
}

// XÓA HẾT
function deleteXoa() {


    for (let i = todos.length - 1; i >= 0; i--) {
        // console.log(todos);
        if (todos[i].done === true) {
            todos.splice(i, 1);

        }
        saveTodos();
        render();
    }

    // lặp ngược để phần tử sau khi xóa không bị dồn về trước

}
render();
// add() chỉ chạy khi bấm nút Add, Còn render(); cuối file chạy NGAY KHI TRANG VỪA LOAD
// nên nếu không bấm nút add thì trang trống không nếu không gọi render ở cuối