# GHI CHÚ
- Dữ liệu nằm trong localStorage (todos)
- Mỗi trang lọc khác nhau
> all.html: chọn all
> active.html: done = false
> completed: done = true
- Tick checkbox = đổi done
- Trang kia tự hiện khi load (render())